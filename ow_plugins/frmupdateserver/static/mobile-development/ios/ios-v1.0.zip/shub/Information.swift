//
//  Information.swift
//  shub
//
//  Created by Yaser Alimardany on 10/11/1395 AP.
//  Copyright © 1395 IISCenter. All rights reserved.
//

import Foundation
class Information{
    var mainMenuItems: [MyMenuItem]
    var footerMenuItems: [MyMenuItem]
    var languageMenuItems: [MyMenuItem]
    var user: User
    
    init(mainMenuItems :[MyMenuItem], footerMenuItems :[MyMenuItem], languageMenuItems :[MyMenuItem], user :User){
        self.mainMenuItems = mainMenuItems
        self.footerMenuItems = footerMenuItems
        self.languageMenuItems = languageMenuItems
        self.user = user
    }
}
