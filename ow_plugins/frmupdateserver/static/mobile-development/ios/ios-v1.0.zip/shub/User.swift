//
//  User.swift
//  shub
//
//  Created by Yaser Alimardani (yaser.alimardany@gmail.com) on 10/11/1395 AP.
//  Copyright © 1395 IISCenter. All rights reserved.
//

import Foundation
class User{
    var name: String
    var email: String
    var avatar: String
    var profileUrl: String
    
    init(name: String, email: String, avatar: String, profileUrl: String){
        self.name = name
        self.email = email
        self.avatar = avatar
        self.profileUrl = profileUrl
    }
}
