//
//  NavigationController.swift
//  shub
//
//  Created by Yaser Alimardani (yaser.alimardany@gmail.com) on 10/17/1395 AP.
//  Copyright © 1395 IISCenter. All rights reserved.
//

import Foundation
class NavigationController: UINavigationController{
    
}
