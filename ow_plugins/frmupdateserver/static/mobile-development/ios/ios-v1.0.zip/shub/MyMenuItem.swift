//
//  MyMenuItem.swift
//  shub
//
//  Created by Yaser Alimardany on 10/11/1395 AP.
//  Copyright © 1395 IISCenter. All rights reserved.
//

import Foundation
class MyMenuItem{
    var label: String = ""
    var href: String = ""
    var tag: String = ""
    var languageId: String = ""
    var isCurrent: Bool
    var isRTL: Bool
    
    init(label: String, href: String){
        self.label = label
        self.href = href
        self.isCurrent = false
        self.isRTL = false
        self.languageId = ""
        self.tag = ""
    }
}
