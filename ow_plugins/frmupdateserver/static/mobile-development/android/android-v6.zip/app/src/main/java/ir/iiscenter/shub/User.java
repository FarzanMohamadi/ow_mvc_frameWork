package ir.iiscenter.shub;

import android.graphics.Bitmap;

/**
 * Created by Alimardani on 10/26/2016.
 */

public class User {
    public String name;
    public String email;
    public Bitmap avatar;
    public String profileUrl;

    User(String name, String email, Bitmap avatar, String profileUrl){
        this.name = name;
        this.email = email;
        this.avatar = avatar;
        this.profileUrl = profileUrl;
    }
}
