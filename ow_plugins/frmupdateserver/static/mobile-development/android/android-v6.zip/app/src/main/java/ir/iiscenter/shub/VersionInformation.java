package ir.iiscenter.shub;

/**
 * Created by pars on 2/18/2017.
 */

public class VersionInformation {
    private String lastVersionUrl = "";
    private String lastVersionName = "";
    private int lastVersionCode = -1;
    private boolean isCurrentDeprecated = false;

    public void setCurrentDeprecated(boolean currentDeprecated) {
        isCurrentDeprecated = currentDeprecated;
    }

    public boolean isCurrentDeprecated() {
        return isCurrentDeprecated;
    }

    public void setLastVersionCode(int lastVersionCode) {
        this.lastVersionCode = lastVersionCode;
    }

    public int getLastVersionCode() {
        return lastVersionCode;
    }

    public void setLastVersionName(String lastVersionName) {
        this.lastVersionName = lastVersionName;
    }

    public String getLastVersionName() {
        return lastVersionName;
    }

    public void setLastVersionUrl(String lastVersionUrl) {
        this.lastVersionUrl = lastVersionUrl;
    }

    public String getLastVersionUrl() {
        return lastVersionUrl;
    }

}
