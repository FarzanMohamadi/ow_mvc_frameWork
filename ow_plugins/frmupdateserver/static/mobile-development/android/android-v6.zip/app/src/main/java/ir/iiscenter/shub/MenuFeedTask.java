package ir.iiscenter.shub;

import android.content.Context;
import android.os.AsyncTask;

/**
 * Created by Alimardani on 10/22/2016.
 */

class MenuFeedTask extends AsyncTask<Context, Void, Information> {

    Context context;

    protected Information doInBackground(Context... params) {
        try {
            this.context = params[0];
            return InformationReceiver.getInformation(this.context);
        } catch (Exception e) {
            return null;
        }
    }

    protected void onPostExecute(Information information) {
        ((MainActivity) context).reconfigureInformation(information);
    }
}
