package ir.iiscenter.shub;

import java.util.ArrayList;

/**
 * Created by Alimardani on 10/22/2016.
 */

public class Information {
    public ArrayList<MyMenuItem> mainMenuItems;
    public ArrayList<MyMenuItem> footerMenuItems;
    public ArrayList<MyMenuItem> languageMenuItems;
    public User user;
    public VersionInformation versionInformation;

    Information(ArrayList<MyMenuItem> mainMenuItems, ArrayList<MyMenuItem> footerMenuItems, ArrayList<MyMenuItem> languageMenuItems, User user, VersionInformation versionInformation){
        this.mainMenuItems = mainMenuItems;
        this.footerMenuItems = footerMenuItems;
        this.languageMenuItems = languageMenuItems;
        this.user = user;
        this.versionInformation = versionInformation;
    }
}
