package ir.iiscenter.shub;

/**
 * Created by Alimardani on 10/15/2016.
 */

public class MyMenuItem {
    public String label;
    public String href;
    public String tag;
    public boolean is_current = false;
    public String language_id;
    public boolean isRtl = false;

    MyMenuItem(String label, String href){
        this.label = label;
        this.href = href;
    }

    public void setLanguageId(String language_id) {
        this.language_id = language_id;
    }

    public void isCurrent(boolean is_current) {
        this.is_current = is_current;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public void setRtl(boolean rtl) {
        isRtl = rtl;
    }

    public boolean isRtl() {
        return isRtl;
    }
}
