package ir.iiscenter.shub;

import android.support.v4.content.FileProvider;

public class CustomFileProvider extends FileProvider {
}
